# laboratorio.conobjetos
Este laboratorio nos permite practicar el diseño con objetos de responsabilidad única.

[![Build status](https://ci.appveyor.com/api/projects/status/dy50tff5fgxqps7o?svg=true)](https://ci.appveyor.com/project/oscarcenteno/laboratorio-conobjetos)
